﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskList
{
    public partial class frmTask : Form
    {
        int TaskID = 0;
        bool ViewMode = false;
        public frmTask(int _TaskId,bool _ViewNode)
        {
            InitializeComponent();
            TaskID = _TaskId;
            ViewMode = _ViewNode;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

      
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtTititle.Text == "")
            {
                MessageBox.Show("Please enter Title","Task Create", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (TaskID > 0)
            {
                if(chkComplete.Checked == true && chkSchedule.Checked ==false)
                {
                    MessageBox.Show("This task is not scheduled", "Task Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            if (Convert.ToDateTime(dtpDueDate.Value)<System.DateTime.Today)
            {
                MessageBox.Show("Past DueDate not allowed.", "Task Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            TodoList t = new TodoList();

            t.Title = txtTititle.Text;
            t.Description = txtDescription.Text;
            t.DueDate = Convert.ToDateTime(dtpDueDate.Value);
            t.Schedule =Convert.ToInt32(chkSchedule.Checked);
            t.Completed =Convert.ToInt32(chkComplete.Checked);
            if(t.Schedule == 1 && t.Completed == 0)
            {
                t.ScheduleDate = System.DateTime.Now;
            }
            if (t.Schedule == 1 && t.Completed == 1)
            {
                t.CompletedDate = System.DateTime.Now;
            }
            if (TaskID == 0)
            {
                if(t.DuplicateCheck(t.Title) == true)
                {
                    MessageBox.Show("Same Task Already Exist", "Task Create", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                t.Insert();
                MessageBox.Show("Task Saved Successfully", "Task Create", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTititle.Text = "";
                txtDescription.Text = "";
                dtpDueDate.Value = System.DateTime.Today;
            }
            else if(TaskID>0)
            {
                t.Update(TaskID);
                MessageBox.Show("Task Updated Successfully", "Task Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
           
        }

        private void frmTask_Load(object sender, EventArgs e)
        {
            if(TaskID>0)
            {
                TodoList t = new TodoList();
                DataTable dt = t.GetData(TaskID);
                if (dt.Rows.Count > 0)
                {
                    txtTititle.Text = dt.Rows[0]["Title"].ToString();
                    txtDescription.Text = dt.Rows[0]["Description"].ToString();
                    dtpDueDate.Value = Convert.ToDateTime(dt.Rows[0]["DueDate"]);
                    if (Convert.ToString(dt.Rows[0]["Schedule"]) != "")
                    {
                        chkSchedule.Checked = Convert.ToBoolean(dt.Rows[0]["Schedule"]);
                        txtTititle.ReadOnly = true;
                        txtDescription.ReadOnly = true;
                        dtpDueDate.Enabled = false;
                        chkSchedule.Enabled = false;
                    }
                   
                    if (Convert.ToString(dt.Rows[0]["Completed"]) != "")
                    {
                        chkComplete.Checked = Convert.ToBoolean(dt.Rows[0]["Completed"]);
                        txtTititle.ReadOnly = true;
                        txtDescription.ReadOnly = true;
                        dtpDueDate.Enabled = false;
                        chkSchedule.Enabled = false;
                        chkComplete.Enabled = false;
                        btnSave.Enabled = false;
                    }
                    if (Convert.ToDateTime(dt.Rows[0]["DueDate"]) <System.DateTime.Today)
                    {                        
                        txtTititle.ReadOnly = true;
                        txtDescription.ReadOnly = true;
                        dtpDueDate.Enabled = false;
                        chkSchedule.Enabled = false;
                        chkComplete.Enabled = false;
                        btnSave.Enabled = false;
                    }
                    if(ViewMode == true)
                    {
                        txtTititle.ReadOnly = true;
                        txtDescription.ReadOnly = true;
                        dtpDueDate.Enabled = false;
                        chkSchedule.Enabled = false;
                        chkComplete.Enabled = false;
                        btnSave.Enabled = false;
                    }
                }                
            }
            if (TaskID == 0)
            {
                chkSchedule.Enabled = false;
                chkComplete.Enabled = false;
            }
           
        }

        private void chkSchedule_CheckedChanged(object sender, EventArgs e)
        {
          /*  if(chkSchedule.Checked == true)
            {
                txtTititle.ReadOnly = true;
                txtDescription.ReadOnly = true;
                dtpDueDate.Enabled = false;
            }
            else
            {
                txtTititle.ReadOnly = true;
                txtDescription.ReadOnly = true;
                dtpDueDate.Enabled = true;
            }*/

        }

        private void chkComplete_CheckedChanged(object sender, EventArgs e)
        {
            /*if (chkComplete.Checked == true)
            {
                txtTititle.ReadOnly = true;
                txtDescription.ReadOnly = true;
                dtpDueDate.Enabled = false;
                chkSchedule.Enabled = false;
                chkComplete.Enabled = false;
            }
            else
            {
                txtTititle.ReadOnly = false;
                txtDescription.ReadOnly = false;
                dtpDueDate.Enabled = true;
                chkSchedule.Enabled = true;
                chkComplete.Enabled = true;
            }*/
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
